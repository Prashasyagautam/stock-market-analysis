# Stock_market_analysis
This repository has our 3rd sem python project, in which numpy and matplotlib is used, where we had analyzed stock prices.
this repository was created by a group of 5 members.
Ipsita Prusty
Omm Hari Shankar Sahoo
Nayab Mirza
Prashasya Gautam
Divyanshu Ajit Dsilva
